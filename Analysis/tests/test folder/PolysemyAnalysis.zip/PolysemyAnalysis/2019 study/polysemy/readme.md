# Folder
## Polyseme Data
Contains information on polysemes when trained using all available data

## Clustering
Contains data and figures related to clustering

## Scores
Results of testing

# polysemy_analysis.py

The main script used to construct and test polysemes. Requires other included classes.